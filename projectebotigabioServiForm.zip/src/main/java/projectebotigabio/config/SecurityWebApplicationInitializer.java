/**
*       Inicialitza la seguretat web d'usuaris
*       @Author Grup3 DAW
*       @Version: 2.0 
*
*/
package projectebotigabio.config;


import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
    
}
